package com.vstack.services;

public interface IOpenStackCliService {

}
